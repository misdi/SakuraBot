module.exports = [
  {
    name: "Stable Diffusion (Default)",
    value:
      "stability-ai/stable-diffusion:27b93a2413e7f36cd83da926f3656280b2931564ff050bf9575f1fdf9bcd7478",
  },
  {
    name: "Dreamshaper",
    value:
      "cjwbw/dreamshaper:ed6d8bee9a278b0d7125872bddfb9dd3fc4c401426ad634d8246a660e387475b",
  },
  {
    name: "Openjourney (Midjourney style)",
    value:
      "prompthero/openjourney:9936c2001faa2194a261c01381f90e65261879985476014a0a37a334593a05eb",
  },
  {
    name: "Mini DALL-E",
    value:
      "kuprel/min-dalle:2af375da21c5b824a84e1c459f45b69a117ec8649c2aa974112d7cf1840fc0ce",
  },
  {
    name: "Waifu Diffusion",
    value:
      "cjwbw/waifu-diffusion:25d2f75ecda0c0bed34c806b7b70319a53a1bccad3ade1a7496524f013f48983",
  },
];
